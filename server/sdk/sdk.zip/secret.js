module.exports = {
    network: "http://localhost:8545",
    pk: "0x98f7816a3960169c016d534b43a8e1079772bda8faac3d96fa52269be6e8677a"
}